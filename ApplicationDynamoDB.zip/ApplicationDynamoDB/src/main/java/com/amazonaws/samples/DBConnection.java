package com.amazonaws.samples;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;

public class DBConnection {
	
	public static AmazonDynamoDBClient createConnection(){
		
		AmazonDynamoDBClient dynamo = null;
		AWSCredentials cred = null;
		Region usWest2 = null;
			
		try{
			 cred = new ProfileCredentialsProvider("default").getCredentials();
		}
		catch(Exception e){
			System.out.println("Unable to fetch credentials from C:\\Users\\prashanth\\.aws\\credentials ");
		}
		
		dynamo = new AmazonDynamoDBClient(cred);
		usWest2 = Region.getRegion(Regions.US_WEST_2);
		dynamo.setRegion(usWest2);
		
		return dynamo;
		
	}
	
}
