package com.amazonaws.samples;

import java.util.*;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;

public class Main {
	
	static AmazonDynamoDBClient dynamoDBClient = null;
	static String tableName = "Employee";
	
	public static void main(String a[]) throws InterruptedException{
		
		dynamoDBClient = DBConnection.createConnection();
		
		List<Employee> employees = new ArrayList<>();
		employees.add(new Employee(1,"ABC","12/2/1990"));
		employees.add(new Employee(2,"DEF","10/3/1991"));
		employees.add(new Employee(3,"GHI","1/2/1992"));
		
		DBOperations.createTable(dynamoDBClient, tableName);
		DBOperations.insertItems(dynamoDBClient, tableName, employees);
		
		
		System.out.println("----------------------------------");
		//AmazonDynamoDB dynamo = AmazonDynamoDBClientBuilder.standard().build();
		//dynamo.setRegion(Region.getRegion(Regions.US_WEST_2));
			System.out.println("----------------------------------");
		
		DynamoDB db = new DynamoDB(dynamoDBClient);
		Table table = db.getTable("Employee");
		
		table.delete();
		table.waitForDelete();
		
		System.out.println(" Table deleted successfully ");
		
	}
	
	
	
	
	
	
	
}




