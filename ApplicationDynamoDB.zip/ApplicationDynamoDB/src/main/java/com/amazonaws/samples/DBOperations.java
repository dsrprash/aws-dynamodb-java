package com.amazonaws.samples;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.UpdateItemOutcome;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.dynamodbv2.util.TableUtils;
import com.amazonaws.services.dynamodbv2.util.TableUtils.TableNeverTransitionedToStateException;

public class DBOperations {
	
	public static void createTable(AmazonDynamoDBClient addbc,String tbName) throws TableNeverTransitionedToStateException, InterruptedException{
			
		CreateTableRequest ctr = new CreateTableRequest().withTableName(tbName).withKeySchema(new KeySchemaElement().withAttributeName("Id").withKeyType(KeyType.HASH))
					.withAttributeDefinitions(new AttributeDefinition().withAttributeName("Id").withAttributeType(ScalarAttributeType.N))
					.withProvisionedThroughput(new ProvisionedThroughput().withReadCapacityUnits(1L).withWriteCapacityUnits(1L));
		
		TableUtils.createTableIfNotExists(addbc, ctr);
		TableUtils.waitUntilActive(addbc, tbName);
		
	}
	
	public static void insertItems(AmazonDynamoDBClient addbc,String tbName,List<Employee> list){
		Map<String, AttributeValue> item = null;
		PutItemRequest putItemRequest = null;
		PutItemResult putItemResult = null;
		
		for(Employee e:list){
			item = newItem(e);
			putItemRequest = new PutItemRequest(tbName,item);
			putItemResult = addbc.putItem(putItemRequest);
			System.out.println(" Result : \""+e.getName()+"\" successfully inserted !");
		}
	}
	
	
	public static void readItem(AmazonDynamoDBClient addbc,String tbName){
		ScanRequest scanRequest = new ScanRequest().withTableName("Employee");
		ScanResult scanResult = addbc.scan(scanRequest);
		for(Map<String,AttributeValue> m: scanResult.getItems())
			System.out.println(m);
		
	}
	
	public static void deleteTable(AmazonDynamoDBClient addbc,String tbName) {
		DynamoDB db = new DynamoDB(addbc);
		Table table = db.getTable("Employee");
		
		table.delete();
		try{
		table.waitForDelete();
		}catch(Exception e){
			System.out.println("Error in deleting table");
		}
		System.out.println(" Table deleted successfully ");
		
	}
	
	public static void updateTable(AmazonDynamoDBClient addbc,String tbName){
		DynamoDB ddb = new DynamoDB(addbc);
		Table table = ddb.getTable(tbName);
		UpdateItemSpec updateItemSpec = new UpdateItemSpec().withPrimaryKey("Id",2)
				.withUpdateExpression("set Name = :n").withValueMap(new ValueMap().withString("n","ZZZzZZ")).withReturnValues(ReturnValue.UPDATED_NEW);
		try{
			
			UpdateItemOutcome updateItemOutcome = table.updateItem(updateItemSpec);
			System.out.println("Update...Successfull!!");
		}catch(Exception e){
			System.out.println("Unable to Update the item");
		}
		
	}
	
	
	public static Map<String,AttributeValue> newItem(Employee e){
		Map<String,AttributeValue> newRecord = new HashMap<>();
		newRecord.put("Id", new AttributeValue().withN(Integer.toString(e.getId())));
		newRecord.put("Name", new AttributeValue().withS(e.getName()));
		newRecord.put("DOB", new AttributeValue().withS(e.getDob()));
		return newRecord;
		
	}
	
	
}
